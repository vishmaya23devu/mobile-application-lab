package com.example.multiplication;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

public class MainActivity extends AppCompatActivity {
    EditText number;
    Button table;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        number = findViewById(R.id.number);
        table = findViewById(R.id.table);
        table.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String a = number.getText().toString();
                if (!a.isEmpty()) {


                    Integer n = Integer.parseInt(a);
                    String res="";
                    for (int i = 1;i<10;i++){
                        res+= n+"*"+i+"="+n*i+"\n";
                    }
                        Intent intent = new Intent(MainActivity.this, answer.class);
                    intent.putExtra("result",res);
                    startActivity(intent);
                }
            }
        });
    }
}
