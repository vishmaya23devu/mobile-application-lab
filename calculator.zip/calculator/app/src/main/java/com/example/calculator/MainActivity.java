package com.example.calculator;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity implements View.OnClickListener{
    Button badd, bsub, bmul, bdiv;
    EditText enum1, enum2;
    TextView Tans;
    int n1, n2;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        badd = findViewById(R.id.add);
        bsub = findViewById(R.id.sub);
        bmul = findViewById(R.id.mul);
        bdiv = findViewById(R.id.div);
        enum1 = findViewById(R.id.num1);
        enum2 = findViewById(R.id.num2);
        Tans = findViewById(R.id.ans);

        badd.setOnClickListener(this);
        bsub.setOnClickListener(this);
        bmul.setOnClickListener(this);
        bdiv.setOnClickListener(this);
    }
    @Override
            public void onClick(View view){
        n1 = Integer.parseInt(enum1.getText().toString());
        n2 = Integer.parseInt(enum2.getText().toString());
        float res = 0;
        int id = view.getId();
        if (id == R.id.add) {
            res = n1 + n2;
        } else if (id == R.id.sub) {
            res = n1 - n2;
        } else if (id == R.id.mul) {
            res = n1 * n2;
        } else if (id == R.id.div) {
            res = (float) n1 / (float) n2;
        }
       Tans.setText("answer"+ res);
    }
}

