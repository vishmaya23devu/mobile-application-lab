package com.example.calculator;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.widget.TextView;

public class result extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_result);
        float result = getIntent().getFloatExtra("RESULT",0.0f);
        TextView Tresult = findViewById(R.id.result);
        Tresult.setText("answer" + Tresult);
    }
}