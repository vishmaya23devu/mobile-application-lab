package com.example.validation;

import androidx.appcompat.app.AppCompatActivity;

import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

public class result extends AppCompatActivity {
 TextView name , email;
 Button  logout;
 SharedPreferences sp;
    private static final String spName="mypref";
    private static final String keyName="n";
    private static final String keyEmail="e";

    private  static final  String keypass = "p";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_result);
        name=findViewById(R.id.textName);
        email=findViewById(R.id.temail);
        logout=findViewById(R.id.logout);

        sp=getSharedPreferences(spName,MODE_PRIVATE);
        String n=sp.getString(keyName,null);
        String e=sp.getString(keyEmail,null);

        if (name!=null || email!=null) {
            //Set data on this page
            name.setText("Full Name : " + n);
            email.setText("Email Id : " + e);
        }
       logout.setOnClickListener(new View.OnClickListener() {
           @Override
           public void onClick(View v) {
               SharedPreferences.Editor editor= sp.edit();
               editor.clear();
               editor.commit();
               Toast.makeText(result.this, "logout", Toast.LENGTH_SHORT).show();
               finish();
           }
       });


            }
}