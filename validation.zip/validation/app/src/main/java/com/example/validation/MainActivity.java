package com.example.validation;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {
EditText user , email, password;
Button register;
SharedPreferences sp;
    private static final String spNAME="mypref";
    private static final String keyName="n";
    private static final String keyEmail="e";
    private  static final  String keypass = "p";
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        user= findViewById(R.id.username);
        email = findViewById(R.id.email);
        password = findViewById(R.id.password);
        register = findViewById(R.id.register);
        sp = getSharedPreferences(spNAME,MODE_PRIVATE);
        String n = sp.getString(keyName,null);
        if (n!= null)
        {
            Intent intent = new Intent(MainActivity.this, result.class);
            startActivity(intent);
        }
        register.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                SharedPreferences.Editor editor= sp.edit();
                editor.putString(keyName,user.getText().toString());
                editor.putString(keyEmail,email.getText().toString());
                editor.putString(keypass,password.getText().toString());
                editor.apply();
                Intent intent = new Intent(MainActivity.this,result.class);
                startActivity(intent);
                Toast.makeText(MainActivity.this,"login success",Toast.LENGTH_SHORT).show();





            }
        });

    }
}