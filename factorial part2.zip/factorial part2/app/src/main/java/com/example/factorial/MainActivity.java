package com.example.factorial;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

public class MainActivity extends AppCompatActivity {
EditText number;
Button answer;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        number= findViewById(R.id.number);
        answer = findViewById(R.id.result);
        answer.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
               String num = number.getText().toString();
               int inputNumber = Integer.parseInt(num);
                   int fact = 1;
                   String res ="";
                    for (int i = 1; i<= inputNumber;i++) {
                        fact *= i;
                        res+=fact+"\n";
                        Intent intent = new Intent(MainActivity.this, result.class);
                    intent.putExtra("Result", res);
                    startActivity(intent);
               }

            }
        });
    }
}