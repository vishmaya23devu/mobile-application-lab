package com.example.fibo;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {
    EditText number;
    Button generate;
    TextView result;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        number= findViewById(R.id.num);
        generate= findViewById(R.id.generate);
        result= findViewById(R.id.result);

        generate.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String num = number.getText().toString();
                int a = Integer.parseInt(num);
                int first = 0 , second = 1;
                int next = 0;

                for (int i =0;i<a;i++){

                    next = first + second;
                    first = second;
                    second = next;
                }
                result.setText("answer"+ next);
            }
        });
    }
}