package com.example.multiplication;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.widget.LinearLayout;
import android.widget.TextView;


public class answer extends AppCompatActivity {
LinearLayout layout;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_answer);
        int a = getIntent().getIntExtra("number", 0);
        layout = findViewById(R.id.layout);
        for (int i = 1; i <= 10; i++) {
            TextView ans = new TextView(this);
            ans.setText(String.format("%d x %d = %d", a, i, a * i));
            layout.addView(ans);
        }
    }
        }

